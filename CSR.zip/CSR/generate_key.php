<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$downloadDir = __DIR__ . "/download";
if (!file_exists($downloadDir)) {
    mkdir($downloadDir, 0777, true);
}

// Get POST inputs
$countryName = $_POST['countryName'] ?? '';
$state = $_POST['state'] ?? '';
$locality = $_POST['locality'] ?? '';
$organization = $_POST['organization'] ?? '';
$orgUnit = $_POST['organizationUnit'] ?? '';
$commonName = $_POST['commonName'] ?? '';
$subjectAltName = $_POST['subjectAltName'] ?? '';
$altType = $_POST['altType'] ?? 'SAN';  // "SAN" or "Wild Card"
$keySize = intval($_POST['keySize'] ?? 2048);

// Basic validation
if (!$commonName) {
    die("Common Name is required.");
}
if ($keySize < 1024) {
    die("Key size must be at least 1024 bits.");
}

// If Wild Card selected, ensure commonName starts with "*."
if ($altType === 'Wild Card' && stripos($commonName, '*.') !== 0) {
    die("❌ Common Name must start with '*.' for wildcard CSR (e.g., *.example.com)");
}

// Prepare DN
$dn = [
    "countryName" => $countryName,
    "stateOrProvinceName" => $state,
    "localityName" => $locality,
    "organizationName" => $organization,
    "organizationalUnitName" => $orgUnit,
    "commonName" => $commonName,
];

// Generate private key
$privateKey = openssl_pkey_new([
    "private_key_type" => OPENSSL_KEYTYPE_RSA,
    "private_key_bits" => $keySize,
]);

if (!$privateKey) {
    die("Failed to generate private key.");
}

// Set CSR options
$csrOptions = [
    "digest_alg" => "sha256"
];

$configPath = null;
$sanList = [];

if ($altType === 'SAN') {
    // Process SANs
    $sanListRaw = explode(',', $subjectAltName);
    foreach ($sanListRaw as $entry) {
        $entry = trim($entry);
        if (!$entry) continue;
        $sanList[] = stripos($entry, 'DNS:') === 0 ? $entry : 'DNS:' . $entry;
    }

    if (!empty($sanList)) {
        // Build temporary OpenSSL config with SAN
        $sanFormatted = implode(", ", $sanList);
        $configContent = "[req]
distinguished_name = req_distinguished_name
prompt = no
req_extensions = req_ext

[req_distinguished_name]
C = {$countryName}
ST = {$state}
L = {$locality}
O = {$organization}
OU = {$orgUnit}
CN = {$commonName}

[req_ext]
subjectAltName = $sanFormatted
";

        $configPath = sys_get_temp_dir() . "/openssl_" . uniqid() . ".cnf";
        file_put_contents($configPath, $configContent);
        $csrOptions["config"] = $configPath;
        $csrOptions["req_extensions"] = "req_ext";
    }
}

// Generate CSR
$csr = openssl_csr_new($dn, $privateKey, $csrOptions);
if (!$csr) {
    if ($configPath) unlink($configPath);
    die("Failed to generate CSR.");
}

// Export CSR and Private Key
openssl_csr_export($csr, $csrOut);
openssl_pkey_export($privateKey, $privateKeyOut);

// Save files
$csrFile = "$downloadDir/{$commonName}.csr";
$keyFile = "$downloadDir/{$commonName}.key";
file_put_contents($csrFile, $csrOut);
file_put_contents($keyFile, $privateKeyOut);

// Verify match
$privateKeyDetails = openssl_pkey_get_details($privateKey);
$privateKeyModulus = $privateKeyDetails['rsa']['n'] ?? null;

$csrDetails = openssl_csr_get_public_key($csr);
$csrKeyDetails = openssl_pkey_get_details($csrDetails);
$csrModulus = $csrKeyDetails['rsa']['n'] ?? null;

$matchStatus = ($privateKeyModulus === $csrModulus) ? "✅ Keys match." : "❌ Keys do NOT match.";

// Clean up config
if ($configPath) unlink($configPath);

// Output
echo "<h4>✅ CSR Information:</h4><pre>";
echo "Type: $altType\n";
echo "Common Name: $commonName\n";
if (!empty($sanList)) {
    echo "Subject Alternative Names: " . implode(', ', $sanList) . "\n";
}
echo "Organization: $organization\n";
echo "Org Unit: $orgUnit\n";
echo "Locality: $locality\n";
echo "State: $state\n";
echo "Country: $countryName\n";
echo "Key Size: {$keySize} bit\n";
echo "</pre>";

echo "<h4>🔐 CSR and Private Key Match Status:</h4>";
echo "<p style='font-weight:bold;'>$matchStatus</p>";

echo "<h4>⬇️ Download Files</h4>";
echo "<a href='download/{$commonName}.csr' download>Download CSR</a><br>";
echo "<a href='download/{$commonName}.key' download>Download Private Key</a><br>";
?>

